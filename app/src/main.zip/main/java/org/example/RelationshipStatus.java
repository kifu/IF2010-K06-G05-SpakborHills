
public enum RelationshipStatus {
    SINGLE,
    FIANCE,
    SPOUSE
}
