public class Equipment extends Item {
    public Equipment(String name) {
        super("Equipment", name, -1, -1);
    }

    public Equipment getEquipment() {
        return this;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
