public interface Edible {
    public int getEnergyRes();
}
